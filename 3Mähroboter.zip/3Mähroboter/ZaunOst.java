
/**
 * Der Zaum als Hindernis.
 * 
 * @author Albert Wiedemann 
 * @version 1.0
 */
class ZaunOst extends Rechteck
{

    /**
     * Plaziert den Zaun
     */
    ZaunOst ()
    {
        super();
        FarbeSetzen("braun");
        PositionSetzen(590, 0);
        GrößeSetzen(10, 500);
    }
}
