
/**
 * Der Zaum als Hindernis.
 * 
 * @author Albert Wiedemann 
 * @version 1.0
 */
class ZaunNord extends Rechteck
{

    /**
     * Plaziert den Zaun
     */
    ZaunNord ()
    {
        super();
        FarbeSetzen("braun");
        PositionSetzen(0, 0);
        GrößeSetzen(600, 10);
    }
}
