
/**
 * Die Rasenfläche.
 * 
 * @author Albert Weidemann 
 * @version 1.0
 */
class Rasen extends Rechteck
{

    /**
     * Plaziert den Rasen.
     */
    Rasen ()
    {
        super();
        FarbeSetzen("grün");
        PositionSetzen(0, 10);
        GrößeSetzen(600, 490);
    }
}
